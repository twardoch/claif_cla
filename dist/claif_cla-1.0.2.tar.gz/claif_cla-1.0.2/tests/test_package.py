"""Test suite for claif_cla."""

import claif_cla


def test_version():
    """Verify package exposes version."""
    assert claif_cla.__version__
